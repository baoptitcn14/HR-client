export const environment = {
    domain: '.app.trenet.com.vn',
    sysAPI: 'http://app.trenet.com.vn',
    baseUrl: 'http://localhost:4200',
    loginUrl: 'http://app.trenet.com.vn/sso/user/login#http://localhost:4200',
    homeUrl: '/home'
};
