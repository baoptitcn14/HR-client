export const environment = {
    domain: '.localhost',
    sysAPI: 'http://localhost:5010',
    baseUrl: 'http://localhost:4800',
    loginUrl: 'http://app.trenet.com.vn/sso/user/login#http://localhost:4800',
    homeUrl: '/home'
};
